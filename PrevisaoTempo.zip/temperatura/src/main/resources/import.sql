insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (1, 'Domingo', 31, 18, 57, 0, 'Céu Limpo');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (2, 'Segunda-Feira', 32, 18, 42, 0,  'Céu Limpo');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (3, 'Terça-Feira', 33, 19, 39, 0, 'Sol entre Nuvens');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (4, 'Quarta-Feira', 33, 19, 42, 0, 'Sol entre Nuvens');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (5, 'Quinta-Feira', 34, 18, 42, 20, 'Sol entre Nuvens');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (6, 'Sexta-Feira', 27, 18, 64, 20, 'Sol entre Nuvens');
insert into temperatura(id, dia, temperatura_maxima, temperatura_minima, humidade, chuva, descricao) values (7, 'Sábado', 24, 17, 72, 20, 'Sol entre Nuvens');
